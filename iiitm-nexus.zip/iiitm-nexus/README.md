# IIITM Nexus
Open index.html in any modern browser (internet needed for the Tailwind and Google Fonts CDNs). No sign-in, no build step.
Campus, faculty and placement details come from public IIIT Manipur pages and third-party aggregators; verify at iiitmanipur.ac.in.
